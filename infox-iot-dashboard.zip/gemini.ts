// No static import for @google/genai

// Cache the AI client instance. The type will be inferred after dynamic import.
let ai: any | null = null;

/**
 * Lazily initializes and returns the GoogleGenAI client.
 * This prevents the app from crashing by dynamically importing the module only when needed.
 */
async function getAiClient(): Promise<any | null> {
  // Return cached instance if available.
  if (ai) {
    return ai;
  }

  try {
    // Dynamically import the library to avoid top-level errors on app load.
    const { GoogleGenAI } = await import('@google/genai');
    
    // Accessing process.env can throw a ReferenceError in some environments.
    const apiKey = process.env.API_KEY;

    if (apiKey) {
      // Initialize and cache the client.
      ai = new GoogleGenAI({ apiKey });
      return ai;
    } else {
      console.warn("API_KEY environment variable not found. AI features will be disabled.");
      return null;
    }
  } catch (e) {
    console.error("Failed to initialize the Google GenAI client. AI features will be disabled.", e);
    return null;
  }
}

export async function generateNotificationText(prompt: string): Promise<string> {
  const geminiClient = await getAiClient();

  if (!geminiClient) {
    console.error("Gemini API client is not available.");
    return "AI features are currently unavailable.";
  }

  try {
    const response = await geminiClient.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating notification text:", error);
    // Provide a user-friendly error message if the API call fails.
    return "Notification generation failed. Please try again.";
  }
}
