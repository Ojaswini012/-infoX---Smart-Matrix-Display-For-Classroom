
import React, { useState, useCallback, useEffect } from 'react';
import { Page, Reminder, Device, Room, UserRole } from './types';
import BottomNav from './components/BottomNav';
import HomePage from './components/pages/HomePage';
import DevicesPage from './components/pages/DevicesPage';
import RemindersPage from './components/pages/RemindersPage';
import ContactPage from './components/pages/ContactPage';
import ProfilePage from './components/pages/ProfilePage';
import AboutPage from './components/pages/AboutPage';
import Modal from './components/Modal';
import NotificationPopup from './components/NotificationPopup';
import SMSNotification from './components/SMSNotification';
import SplashScreen from './components/SplashScreen';
import AuthPage from './components/AuthPage';
import AddReminderForm from './components/forms/AddReminderForm';
import AddDeviceForm from './components/forms/AddDeviceForm';
import CreateRoomForm from './components/forms/CreateRoomForm';
import JoinRoomForm from './components/forms/JoinRoomForm';
import { generateNotificationText } from './gemini';

export default function App() {
  // Auth State
  const [isAppLoading, setAppLoading] = useState(true);
  const [isAuthenticated, setAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState<UserRole | null>(null);

  // App State
  const [currentPage, setCurrentPage] = useState<Page>(Page.Dashboard);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [devices, setDevices] = useState<Device[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [joinedRooms, setJoinedRooms] = useState<string[]>([]);
  const [notifications, setNotifications] = useState<{ id: number; message: string }[]>([]);
  const [smsNotification, setSmsNotification] = useState<string | null>(null);

  // Modal State
  const [isReminderModalOpen, setReminderModalOpen] = useState(false);
  const [isDeviceModalOpen, setDeviceModalOpen] = useState(false);
  const [isCreateRoomModalOpen, setCreateRoomModalOpen] = useState(false);
  const [isJoinRoomModalOpen, setJoinRoomModalOpen] = useState(false);
  const [isGenerating, setGenerating] = useState(false);

  // Simulate app loading
  useEffect(() => {
    const timer = setTimeout(() => setAppLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  // Show notification for user
  const showSmsNotification = useCallback((message: string) => {
    setSmsNotification(message);
  }, []);

  // UI feedback notifications
  const addNotification = useCallback((message: string) => {
    const newNotification = { id: Date.now(), message };
    setNotifications(prev => [...prev, newNotification]);
  }, []);
  
  const removeUINotification = useCallback((id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  // Auth handlers
  const handleLogin = (role: UserRole) => {
    setUserRole(role);
    setAuthenticated(true);
    setCurrentPage(Page.Dashboard);
  };

  const handleLogout = () => {
    setUserRole(null);
    setAuthenticated(false);
  };
  
  const handleSwitchRole = () => {
      setUserRole(prev => prev === 'admin' ? 'user' : 'admin');
      addNotification(`Switched to ${userRole === 'admin' ? 'User' : 'Admin'} view.`);
  };

  // Handlers
  const addReminder = async (title: string, time: string) => {
    let reminderTitle = title;
    if (title.toLowerCase().startsWith('generate:')) {
      setGenerating(true);
      const prompt = title.substring('generate:'.length).trim();
      reminderTitle = await generateNotificationText(prompt);
      setGenerating(false);
    }
    const newReminder = { id: Date.now(), title: reminderTitle, time, active: true };
    setReminders(prev => [...prev, newReminder]);
    showSmsNotification(`New reminder set: "${reminderTitle}" at ${time}`);
    addNotification('Reminder added!');
  };

  const toggleReminder = (id: number) => {
    setReminders(reminders.map(r => r.id === id ? { ...r, active: !r.active } : r));
  };
  
  const addDevice = async (name: string) => {
    let deviceName = name;
     if (name.toLowerCase().startsWith('generate:')) {
      setGenerating(true);
      const prompt = name.substring('generate:'.length).trim();
      deviceName = await generateNotificationText(prompt);
      setGenerating(false);
    }
    const newDevice = { id: Date.now(), name: deviceName };
    setDevices(prev => [...prev, newDevice]);
    addNotification('Device connected!');
  };
  
  const disconnectDevice = (id: number) => {
      setDevices(prev => prev.filter(d => d.id !== id));
      addNotification('Device disconnected.');
  };

  const addRoom = (name: string) => {
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    const newRoom = { id: Date.now(), name, code };
    setRooms(prev => [...prev, newRoom]);
    addNotification(`Room "${name}" created with code: ${code}`);
  };

  const joinRoom = (code: string) => {
    const roomExists = rooms.some(room => room.code === code);
    if(roomExists && !joinedRooms.includes(code)) {
      setJoinedRooms(prev => [...prev, code]);
      addNotification(`Joined room with code: ${code}`);
      setJoinRoomModalOpen(false);
    } else if (joinedRooms.includes(code)) {
      addNotification(`You are already in room: ${code}`);
    } else {
      addNotification(`Room with code ${code} not found.`);
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case Page.Dashboard:
        return <HomePage 
            reminders={reminders}
            devices={devices}
            rooms={rooms}
            joinedRooms={joinedRooms}
            onAddReminderClick={() => setReminderModalOpen(true)}
            onAddRoomClick={() => setCreateRoomModalOpen(true)}
            onJoinRoomClick={() => setJoinRoomModalOpen(true)}
            userRole={userRole}
            setCurrentPage={setCurrentPage}
        />;
      case Page.Devices:
          return <DevicesPage devices={devices} onAddDeviceClick={() => setDeviceModalOpen(true)} onDisconnectDevice={disconnectDevice} />;
      case Page.Reminders:
          return <RemindersPage reminders={reminders} onAddReminderClick={() => setReminderModalOpen(true)} toggleReminder={toggleReminder} />;
      case Page.Contact:
        return <ContactPage />;
      case Page.Profile:
        return <ProfilePage onLogout={handleLogout} userRole={userRole} onSwitchRole={handleSwitchRole} />;
      case Page.About:
        return <AboutPage />;
      default:
        return <HomePage 
            reminders={reminders}
            devices={devices}
            rooms={rooms}
            joinedRooms={joinedRooms}
            onAddReminderClick={() => setReminderModalOpen(true)}
            onAddRoomClick={() => setCreateRoomModalOpen(true)}
            onJoinRoomClick={() => setJoinRoomModalOpen(true)}
            userRole={userRole}
            setCurrentPage={setCurrentPage}
        />;
    }
  };

  if (isAppLoading) {
    return <SplashScreen />;
  }

  if (!isAuthenticated) {
    return <AuthPage onLogin={handleLogin} addNotification={addNotification} />;
  }

  return (
    <div className="min-h-screen bg-base text-on-surface flex flex-col font-sans">
      {smsNotification && <SMSNotification message={smsNotification} onClose={() => setSmsNotification(null)} />}
      
      <main className="flex-grow pb-24 px-4 sm:px-6 lg:px-8">
        {renderPage()}
      </main>
      <BottomNav currentPage={currentPage} setCurrentPage={setCurrentPage} />
      
      <Modal isOpen={isReminderModalOpen} onClose={() => setReminderModalOpen(false)}>
        <AddReminderForm isGenerating={isGenerating} addReminder={addReminder} onClose={() => setReminderModalOpen(false)} />
      </Modal>

      <Modal isOpen={isDeviceModalOpen} onClose={() => setDeviceModalOpen(false)}>
        <AddDeviceForm isGenerating={isGenerating} addDevice={addDevice} onClose={() => setDeviceModalOpen(false)} />
      </Modal>

      <Modal isOpen={isCreateRoomModalOpen} onClose={() => setCreateRoomModalOpen(false)}>
        <CreateRoomForm addRoom={addRoom} onClose={() => setCreateRoomModalOpen(false)} />
      </Modal>

       <Modal isOpen={isJoinRoomModalOpen} onClose={() => setJoinRoomModalOpen(false)}>
        <JoinRoomForm handleJoinRoom={joinRoom} />
      </Modal>

      <div className="fixed top-5 right-5 z-50 flex flex-col gap-2">
        {notifications.map(notification => (
          <NotificationPopup
            key={notification.id}
            message={notification.message}
            onClose={() => removeUINotification(notification.id)}
          />
        ))}
      </div>
    </div>
  );
}
