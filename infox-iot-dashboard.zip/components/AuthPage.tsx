
import React, { useState } from 'react';
import { UserRole } from '../types';
import { FullLogo } from './Logo';

const GoogleIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg viewBox="0 0 48 48" {...props}>
        <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12s5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24s8.955,20,20,20s20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"></path>
        <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"></path>
        <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.222,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"></path>
        <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571l6.19,5.238C42.022,35.283,44,30.038,44,24C44,22.659,43.862,21.35,43.611,20.083z"></path>
    </svg>
);


interface AuthPageProps {
    onLogin: (role: UserRole) => void;
    addNotification: (message: string) => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onLogin, addNotification }) => {
    const [role, setRole] = useState<UserRole>('user');
    const [authMode, setAuthMode] = useState<'signIn' | 'signUp'>('signIn');
    
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (authMode === 'signUp' && password !== confirmPassword) {
            addNotification("Passwords do not match!");
            return;
        }
        addNotification(`Successfully signed in as ${role}.`);
        onLogin(role);
    };

    const toggleAuthMode = (e: React.MouseEvent) => {
        e.preventDefault();
        setEmail('');
        setPassword('');
        setConfirmPassword('');
        setAuthMode(prevMode => (prevMode === 'signIn' ? 'signUp' : 'signIn'));
    };
    
    const handleGoogleSignIn = () => {
        addNotification("Successfully signed in with Google.");
        onLogin('user');
    };

    return (
        <div className="min-h-screen bg-base flex flex-col items-center justify-center p-4">
            <div className="w-full max-w-sm text-center">
                <FullLogo className="w-48 mx-auto" />
                <p className="text-lg text-on-surface-secondary mt-4 mb-8">
                     {authMode === 'signIn' ? 'Your IoT Notification Hub' : 'Create a New Account'}
                </p>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <input
                        type="email"
                        placeholder="Email Address"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        required
                        className="w-full bg-surface text-white p-4 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-primary"
                        aria-label="Email Address"
                    />
                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        required
                        className="w-full bg-surface text-white p-4 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-primary"
                        aria-label="Password"
                    />
                    
                    {authMode === 'signUp' && (
                        <input
                            type="password"
                            placeholder="Confirm Password"
                            value={confirmPassword}
                            onChange={e => setConfirmPassword(e.target.value)}
                            required
                            className="w-full bg-surface text-white p-4 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-primary"
                            aria-label="Confirm Password"
                        />
                    )}
                    
                    <div className="text-left">
                        <span className="text-sm font-medium text-on-surface-secondary">Select your role:</span>
                        <div className="mt-2 flex gap-4">
                            <label className="flex items-center gap-2 cursor-pointer">
                                <input type="radio" name="role" value="user" checked={role === 'user'} onChange={() => setRole('user')} className="form-radio bg-gray-700 text-primary focus:ring-primary"/>
                                <span className="text-white">User</span>
                            </label>
                            <label className="flex items-center gap-2 cursor-pointer">
                                <input type="radio" name="role" value="admin" checked={role === 'admin'} onChange={() => setRole('admin')} className="form-radio bg-gray-700 text-primary focus:ring-primary"/>
                                <span className="text-white">Admin</span>
                            </label>
                        </div>
                    </div>

                    <button type="submit" className="w-full bg-primary text-base font-bold py-4 px-6 rounded-lg hover:bg-opacity-80 transition-colors">
                        {authMode === 'signIn' ? 'Sign In' : 'Sign Up'}
                    </button>
                </form>

                <div className="my-6 flex items-center">
                    <hr className="w-full border-gray-700"/>
                    <span className="px-4 text-on-surface-secondary">OR</span>
                    <hr className="w-full border-gray-700"/>
                </div>

                <button
                    onClick={handleGoogleSignIn}
                    className="w-full bg-white text-gray-800 font-semibold py-3 px-6 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-3"
                >
                    <GoogleIcon className="w-6 h-6" />
                    {authMode === 'signIn' ? 'Sign in with Google' : 'Sign up with Google'}
                </button>
                 <p className="text-on-surface-secondary mt-8">
                     {authMode === 'signIn' ? "Don't have an account?" : "Already have an account?"}
                    <a href="#" onClick={toggleAuthMode} className="font-semibold text-primary hover:underline ml-1">
                        {authMode === 'signIn' ? 'Sign Up' : 'Sign In'}
                    </a>
                </p>
            </div>
        </div>
    );
};

export default AuthPage;
