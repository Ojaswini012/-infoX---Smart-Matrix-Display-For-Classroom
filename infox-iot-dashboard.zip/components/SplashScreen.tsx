import React from 'react';
import { FullLogo } from './Logo';

const SplashScreen: React.FC = () => {
    return (
        <div className="fixed inset-0 bg-base flex flex-col items-center justify-center z-50">
            <FullLogo className="w-64" />
        </div>
    );
};

export default SplashScreen;
