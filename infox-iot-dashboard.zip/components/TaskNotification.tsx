import React, { useEffect, useState } from 'react';
import { Task } from '../../types';
import Logo from './Logo';

interface TaskNotificationProps {
  task: Task;
  onClose: (id: string) => void;
  onMarkAsDone: (id: string) => void;
  onSnooze: (id: string) => void;
}

const TaskNotification: React.FC<TaskNotificationProps> = ({ task, onClose, onMarkAsDone, onSnooze }) => {
    const [visible, setVisible] = useState(false);

    useEffect(() => {
        setVisible(true); // Animate in
        const timer = setTimeout(() => {
            handleClose();
        }, 30000); // Auto-close after 30 seconds

        return () => clearTimeout(timer);
    }, [task.id]);

    const handleClose = () => {
        setVisible(false);
        setTimeout(() => onClose(task.id), 500);
    }
    
    const handleAction = (action: (id: string) => void) => {
        setVisible(false);
        setTimeout(() => action(task.id), 500);
    }

    return (
        <div 
            className={`
                w-full max-w-sm
                transition-all duration-500 ease-in-out
                ${visible ? 'transform translate-y-0 opacity-100' : 'transform -translate-y-full opacity-0'}
            `}
            role="alert"
            aria-live="assertive"
        >
            <div className="bg-gray-800/80 backdrop-blur-sm rounded-2xl p-3 shadow-2xl border border-gray-700">
                <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                       <Logo width="20" height="20" />
                        <span className="text-primary font-bold text-sm">Task Due!</span>
                    </div>
                    <button onClick={handleClose} className="text-gray-400 text-xs hover:text-white">&times;</button>
                </div>
                <p className="text-on-surface text-sm mb-3 font-medium">{task.title}</p>
                <div className="flex gap-2">
                    <button 
                        onClick={() => handleAction(onMarkAsDone)}
                        className="w-full bg-primary/80 text-base text-sm py-1.5 px-3 rounded-lg hover:bg-primary transition-colors"
                    >
                        Mark as Done
                    </button>
                    <button 
                        onClick={() => handleAction(onSnooze)}
                        className="w-full bg-surface text-on-surface text-sm py-1.5 px-3 rounded-lg hover:bg-gray-700 transition-colors"
                    >
                        Snooze
                    </button>
                </div>
            </div>
        </div>
    );
};

export default TaskNotification;