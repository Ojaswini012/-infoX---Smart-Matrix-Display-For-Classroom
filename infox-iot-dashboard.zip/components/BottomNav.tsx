
import React from 'react';
import { Page } from '../types';
import { NAV_ITEMS } from '../constants';

interface BottomNavProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ currentPage, setCurrentPage }) => {
  return (
    <footer className="fixed bottom-0 left-0 right-0 bg-surface border-t border-gray-700 shadow-lg">
      <nav className="flex justify-around items-center h-20 max-w-2xl mx-auto">
        {NAV_ITEMS.map((item) => {
          const isActive = currentPage === item.page;
          return (
            <button
              key={item.page}
              onClick={() => setCurrentPage(item.page)}
              className={`flex flex-col items-center justify-center w-full h-full transition-colors duration-200 ${
                isActive ? 'text-primary' : 'text-on-surface-secondary hover:text-on-surface'
              }`}
            >
              <item.icon className="w-7 h-7" />
              <span className={`text-xs mt-1 font-medium ${isActive ? 'text-primary' : 'text-on-surface-secondary'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>
    </footer>
  );
};

export default BottomNav;
