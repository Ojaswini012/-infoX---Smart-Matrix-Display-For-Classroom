
import React, { useState } from 'react';

interface JoinRoomFormProps {
    handleJoinRoom: (code: string) => void;
}

const JoinRoomForm: React.FC<JoinRoomFormProps> = ({ handleJoinRoom }) => {
    const [code, setCode] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (code.trim()) {
        handleJoinRoom(code);
        setCode('');
      }
    };
    
    return (
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <h2 className="text-xl font-bold text-white">Join a Room</h2>
        <input 
          type="text" 
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          placeholder="ENTER CODE"
          maxLength={6}
          className="bg-gray-700 text-white p-3 rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary text-center tracking-[0.5em] font-mono"
        />
        <button type="submit" className="bg-primary text-base font-bold py-3 px-6 rounded-lg hover:bg-opacity-80 transition-colors">
          Join Room
        </button>
      </form>
    );
};

export default JoinRoomForm;
