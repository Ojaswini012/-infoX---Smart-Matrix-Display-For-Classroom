
import React, { useState } from 'react';

interface AddDeviceFormProps {
    isGenerating: boolean;
    addDevice: (name: string) => Promise<void>;
    onClose: () => void;
}

const AddDeviceForm: React.FC<AddDeviceFormProps> = ({ isGenerating, addDevice, onClose }) => {
    const [name, setName] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      if (name.trim() && !isGenerating) {
        await addDevice(name);
        setName('');
        onClose();
      }
    };
    
    return (
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <h2 className="text-xl font-bold text-white">Connect New Device</h2>
        <input 
          type="text" 
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Device Name or ID (e.g., Living Room ESP32)"
          className="bg-gray-700 text-white p-3 rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
          disabled={isGenerating}
        />
        <button type="submit" className="bg-primary text-base font-bold py-3 px-6 rounded-lg hover:bg-opacity-80 transition-colors flex items-center justify-center disabled:bg-gray-500 disabled:cursor-not-allowed" disabled={isGenerating}>
          {isGenerating ? 'Generating...' : 'Connect Device'}
        </button>
      </form>
    );
};

export default AddDeviceForm;
