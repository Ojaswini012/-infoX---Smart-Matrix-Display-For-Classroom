
import React, { useState } from 'react';

interface CreateRoomFormProps {
    addRoom: (name: string) => void;
    onClose: () => void;
}

const CreateRoomForm: React.FC<CreateRoomFormProps> = ({ addRoom, onClose }) => {
    const [name, setName] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (name.trim()) {
        addRoom(name);
        setName('');
        onClose();
      }
    };
    
    return (
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <h2 className="text-xl font-bold text-white">Create New Room</h2>
        <input 
          type="text" 
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Room Name (e.g., Classroom A)"
          className="bg-gray-700 text-white p-3 rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
        />
        <button type="submit" className="bg-primary text-base font-bold py-3 px-6 rounded-lg hover:bg-opacity-80 transition-colors">
          Create Room
        </button>
      </form>
    );
};

export default CreateRoomForm;
