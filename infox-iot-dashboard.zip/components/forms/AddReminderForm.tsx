
import React, { useState } from 'react';

interface AddReminderFormProps {
  isGenerating: boolean;
  addReminder: (title: string, time: string) => Promise<void>;
  onClose: () => void;
}

const AddReminderForm: React.FC<AddReminderFormProps> = ({ isGenerating, addReminder, onClose }) => {
  const [title, setTitle] = useState('');
  const [time, setTime] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim() && time.trim() && !isGenerating) {
      await addReminder(title, time);
      setTitle('');
      setTime('');
      onClose();
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <h2 className="text-xl font-bold text-white">Add New Reminder</h2>
      <input 
        type="text" 
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Reminder title"
        className="bg-gray-700 text-white p-3 rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
        disabled={isGenerating}
      />
      <input 
        type="time"
        value={time}
        onChange={(e) => setTime(e.target.value)}
        className="bg-gray-700 text-white p-3 rounded-lg border border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
        disabled={isGenerating}
      />
      <button type="submit" className="bg-primary text-base font-bold py-3 px-6 rounded-lg hover:bg-opacity-80 transition-colors flex items-center justify-center disabled:bg-gray-500 disabled:cursor-not-allowed" disabled={isGenerating}>
        {isGenerating ? 'Generating...' : 'Add Reminder'}
      </button>
    </form>
  );
};

export default AddReminderForm;
