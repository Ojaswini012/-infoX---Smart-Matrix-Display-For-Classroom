import React, { useEffect, useState } from 'react';
import Logo from './Logo';

interface SMSNotificationProps {
  message: string;
  onClose: () => void;
  duration?: number;
}

const SMSNotification: React.FC<SMSNotificationProps> = ({ message, onClose, duration = 7000 }) => {
    const [visible, setVisible] = useState(false);

    useEffect(() => {
        setVisible(true); // Animate in
        const timer = setTimeout(() => {
            setVisible(false);
            setTimeout(onClose, 500); // Wait for animation out before calling parent onClose
        }, duration);

        return () => clearTimeout(timer);
    }, [duration, onClose]);


    return (
        <div 
            className={`
                fixed top-5 left-1/2 -translate-x-1/2 w-full max-w-sm z-50
                transition-all duration-500 ease-in-out
                ${visible ? 'transform translate-y-0 opacity-100' : 'transform -translate-y-full opacity-0'}
            `}
            role="alert"
            aria-live="assertive"
        >
            <div className="bg-gray-800/80 backdrop-blur-sm rounded-2xl p-3 shadow-2xl border border-gray-700">
                <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                       <Logo width="20" height="20" />
                        <span className="text-white font-bold text-sm">InfoX</span>
                    </div>
                    <span className="text-gray-400 text-xs">now</span>
                </div>
                <p className="text-on-surface text-sm">{message}</p>
            </div>
        </div>
    );
};

export default SMSNotification;
