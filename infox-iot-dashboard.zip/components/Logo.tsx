import React from 'react';

const Logo: React.FC<{ width?: string | number; height?: string | number; className?: string }> = ({ width = 128, height = 128, className }) => (
    <img
        src="/logo.svg"
        alt="InfoX Logo"
        width={width}
        height={height}
        className={className}
    />
);

export const FullLogo: React.FC<{ className?: string }> = ({ className }) => (
    <svg viewBox="0 0 200 220" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
        <defs>
            <linearGradient id="logoGradientFull" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#A020F0" />
                <stop offset="100%" stopColor="#22D3EE" />
            </linearGradient>
        </defs>
        <style>
            {`
                .infox-text { font: bold 40px sans-serif; fill: white; text-anchor: middle; letter-spacing: 4px; }
                @media (max-width: 640px) {
                    .infox-text { font-size: 32px; }
                }
            `}
        </style>

        <text x="100" y="50" className="infox-text">INFO X</text>

        <g transform="translate(100, 140) scale(1.1)">
            {/* Outer Hexagon */}
            <path d="M50 0 L93.3 25 L93.3 75 L50 100 L6.7 75 L6.7 25 Z" transform="translate(-50, -50)" stroke="url(#logoGradientFull)" strokeWidth="3" />
            {/* Inner Hexagon */}
            <path d="M50 20 L71.65 32.5 L71.65 67.5 L50 80 L28.35 67.5 L28.35 32.5 Z" transform="translate(-50, -50)" stroke="url(#logoGradientFull)" strokeWidth="2" />
            
            {/* Letter I */}
            <text fontFamily="sans-serif" fontSize="24" fontWeight="bold" fill="white" x="0" y="8" text-anchor="middle">I</text>

            {/* Circuit Lines */}
            <g stroke="url(#logoGradientFull)" strokeWidth="2">
                <line x1="-43.3" y1="25" x2="-21.65" y2="12.5" />
                <circle cx="-35" cy="20" r="3" stroke="none" fill="url(#logoGradientFull)"/>

                <line x1="0" y1="-50" x2="0" y2="-25" />
                
                <line x1="43.3" y1="25" x2="21.65" y2="12.5" />
                <circle cx="35" cy="20" r="3" stroke="none" fill="url(#logoGradientFull)"/>

                <line x1="-43.3" y1="-25" x2="-21.65" y2="-12.5" />
                <circle cx="-35" cy="-20" r="3" stroke="none" fill="url(#logoGradientFull)"/>

                <line x1="43.3" y1="-25" x2="21.65" y2="-12.5" />
                <circle cx="35" cy="-20" r="3" stroke="none" fill="url(#logoGradientFull)"/>

                <line x1="0" y1="50" x2="0" y2="25" />
            </g>
        </g>
    </svg>
);


export default Logo;