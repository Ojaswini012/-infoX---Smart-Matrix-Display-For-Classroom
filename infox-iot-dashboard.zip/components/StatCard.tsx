
import React from 'react';

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: number | string;
}

const StatCard: React.FC<StatCardProps> = ({ icon, label, value }) => {
  return (
    <div className="bg-surface p-4 rounded-lg flex flex-col items-center justify-center text-center shadow-lg">
      {icon}
      <p className="text-4xl font-bold text-white mt-3">{value}</p>
      <p className="text-sm text-on-surface-secondary mt-1">{label}</p>
    </div>
  );
};

export default StatCard;
