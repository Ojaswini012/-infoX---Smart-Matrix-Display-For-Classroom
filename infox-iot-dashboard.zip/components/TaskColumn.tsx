import React from 'react';
import { Task, TaskStatus } from '../../types';
import TaskCard from './TaskCard';

interface TaskColumnProps {
  title: string;
  tasks: Task[];
  onUpdateStatus: (id: string, status: TaskStatus) => void;
  onDelete: (id: string) => void;
}

const TaskColumn: React.FC<TaskColumnProps> = ({ title, tasks, onUpdateStatus, onDelete }) => {
  return (
    <div className="bg-base rounded-lg p-4 h-full">
      <h2 className="text-xl font-bold text-white mb-4 flex justify-between items-center">
        <span>{title}</span>
        <span className="bg-surface text-primary text-sm font-bold rounded-full w-7 h-7 flex items-center justify-center">{tasks.length}</span>
      </h2>
      <div className="space-y-4">
        {tasks.length > 0 ? (
            tasks.map(task => (
                <TaskCard
                    key={task.id}
                    task={task}
                    onUpdateStatus={onUpdateStatus}
                    onDelete={onDelete}
                />
            ))
        ) : (
            <div className="text-center text-on-surface-secondary py-10 border-2 border-dashed border-gray-700 rounded-lg">
                <p>No tasks here</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default TaskColumn;