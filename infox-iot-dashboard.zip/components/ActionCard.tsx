
import React from 'react';

interface ActionCardProps {
  title: string;
  description: string;
  onClick: () => void;
}

const ActionCard: React.FC<ActionCardProps> = ({ title, description, onClick }) => {
  return (
    <button
      onClick={onClick}
      className="bg-surface p-4 rounded-lg text-left w-full hover:bg-gray-800 transition-colors duration-200 shadow-md flex justify-between items-center"
    >
      <div>
        <h3 className="text-lg font-semibold text-white">{title}</h3>
        <p className="text-on-surface-secondary mt-1">{description}</p>
      </div>
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6 text-on-surface-secondary">
        <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
      </svg>
    </button>
  );
};

export default ActionCard;
