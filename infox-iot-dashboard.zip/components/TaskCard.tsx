import React from 'react';
import { Task, TaskStatus } from '../../types';

const ClockIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);

const TrashIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.134-2.033-2.134H8.71c-1.123 0-2.033.954-2.033 2.134v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
    </svg>
);


interface TaskCardProps {
  task: Task;
  onUpdateStatus: (id: string, status: TaskStatus) => void;
  onDelete: (id: string) => void;
}

const statusOptions: { label: string; value: TaskStatus }[] = [
    { label: 'To Do', value: 'todo' },
    { label: 'In Progress', value: 'inProgress' },
    { label: 'Done', value: 'done' },
];

const TaskCard: React.FC<TaskCardProps> = ({ task, onUpdateStatus, onDelete }) => {
    const isOverdue = new Date(task.dueDate) < new Date() && task.status !== 'done';

    const formattedDate = new Date(task.dueDate).toLocaleString(undefined, {
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
    });

  return (
    <div className="bg-surface p-4 rounded-lg shadow-md border-l-4 border-primary/50">
        <div className="flex justify-between items-start">
            <h3 className="text-lg font-semibold text-white pr-2">{task.title}</h3>
            <button onClick={() => onDelete(task.id)} className="text-on-surface-secondary hover:text-red-500 transition-colors flex-shrink-0">
                <TrashIcon className="w-5 h-5" />
            </button>
        </div>
        
        {task.description && (
            <p className="text-on-surface-secondary mt-2 text-sm">{task.description}</p>
        )}
        
        <div className={`mt-4 flex items-center gap-2 text-sm ${isOverdue ? 'text-red-400' : 'text-on-surface-secondary'}`}>
            <ClockIcon className="w-4 h-4" />
            <span>{formattedDate}</span>
            {isOverdue && <span className="font-bold">(Overdue)</span>}
        </div>

        <div className="mt-4">
            <select
                value={task.status}
                onChange={(e) => onUpdateStatus(task.id, e.target.value as TaskStatus)}
                className="w-full bg-gray-700 text-white p-2 rounded-md border border-gray-600 focus:outline-none focus:ring-1 focus:ring-primary text-sm"
            >
                {statusOptions.map(option => (
                    <option key={option.value} value={option.value}>{option.label}</option>
                ))}
            </select>
        </div>
    </div>
  );
};

export default TaskCard;