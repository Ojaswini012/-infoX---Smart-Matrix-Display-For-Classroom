
import React, { useEffect, useState } from 'react';

const CheckCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);

interface NotificationPopupProps {
  message: string;
  onClose: () => void;
  duration?: number;
}

const NotificationPopup: React.FC<NotificationPopupProps> = ({ message, onClose, duration = 3000 }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true);
    const timer = setTimeout(() => {
      setVisible(false);
      // Allow for exit animation before calling onClose
      setTimeout(onClose, 300);
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, onClose]);

  return (
    <div
      className={`
        bg-surface border border-primary/50 shadow-lg rounded-lg
        flex items-center gap-3 p-4 w-full max-w-sm
        transition-all duration-300 ease-in-out
        ${visible ? 'transform translate-x-0 opacity-100' : 'transform translate-x-full opacity-0'}
      `}
    >
      <CheckCircleIcon className="w-6 h-6 text-primary flex-shrink-0" />
      <p className="text-on-surface text-sm font-medium">{message}</p>
    </div>
  );
};

export default NotificationPopup;
