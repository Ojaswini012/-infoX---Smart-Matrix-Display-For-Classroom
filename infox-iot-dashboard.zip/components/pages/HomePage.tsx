
import React from 'react';
import StatCard from '../StatCard';
import ActionCard from '../ActionCard';
import { Reminder, Device, UserRole, Page, Room } from '../../types';
import { BellIcon } from '../../constants';

const WifiIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M8.288 15.038a5.25 5.25 0 0 1 7.424 0M5.106 11.856c3.807-3.808 9.98-3.808 13.788 0M1.924 8.674c5.565-5.565 14.587-5.565 20.152 0M12.53 18.22l-.53.53-.53-.53a.75.75 0 0 1 1.06 0Z" />
    </svg>
);

const SettingsIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.343 3.94c.09-.542.56-1.007 1.11-1.227a48.109 48.109 0 0 1 3.09 0c.55.22 1.02.685 1.11 1.227.09.542-.205 1.08-.746 1.35a48.459 48.459 0 0 1-3.09 0c-.54-.27-.836-.808-.746-1.35Zm-2.074 0c.09-.542.56-1.007 1.11-1.227.481-.198 1.024-.372 1.58-.517a49.42 49.42 0 0 1 4.5 0c.556.145 1.1.319 1.58.517.55.22 1.02.685 1.11 1.227.09.542-.205 1.08-.746 1.35a48.458 48.458 0 0 1-5.002 0c-.54-.27-.836-.808-.746-1.35Zm-2.074 0c.09-.542.56-1.007 1.11-1.227.481-.198 1.024-.372 1.58-.517a49.42 49.42 0 0 1 4.5 0c.556.145 1.1.319 1.58.517.55.22 1.02.685 1.11 1.227.09.542-.205 1.08-.746 1.35a48.459 48.459 0 0 1-5.002 0c-.54-.27-.836-.808-.746-1.35ZM12 6.248v3.832a2.33 2.33 0 0 0 .848 1.84l3.75 2.75a2.33 2.33 0 0 1-2.25 3.832V18a2.33 2.33 0 0 1-4.66 0v-1.5a2.33 2.33 0 0 1 2.25-3.832l-3.75-2.75a2.33 2.33 0 0 1-.848-1.84V6.248a2.33 2.33 0 0 1 4.66 0Z" />
    </svg>
);

const UsersIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m-7.5-2.962a3.75 3.75 0 1 0-7.5 0 3.75 3.75 0 0 0 7.5 0ZM10.5 1.5a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);

interface HomePageProps {
  reminders: Reminder[];
  devices: Device[];
  rooms: Room[];
  joinedRooms: string[];
  onAddReminderClick: () => void;
  onAddRoomClick: () => void;
  onJoinRoomClick: () => void;
  userRole: UserRole | null;
  setCurrentPage: (page: Page) => void;
}

const HomePage: React.FC<HomePageProps> = ({ reminders, devices, rooms, joinedRooms, onAddReminderClick, onAddRoomClick, onJoinRoomClick, userRole, setCurrentPage }) => {
  const activeReminders = reminders.filter(r => r.active).length;

  const AdminDashboard = () => (
    <>
      <section className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard 
          icon={<BellIcon className="w-8 h-8 text-primary" />} 
          label="Unread Notifications" 
          value={0}
        />
        <StatCard 
          icon={<WifiIcon className="w-8 h-8 text-primary" />} 
          label="Active Devices" 
          value={devices.length}
        />
        <StatCard 
          icon={<SettingsIcon className="w-8 h-8 text-primary" />} 
          label="Active Reminders" 
          value={activeReminders}
        />
      </section>

      <section className="mt-12">
        <h2 className="text-2xl font-semibold text-white">Quick Actions</h2>
        <div className="mt-4 flex flex-col gap-4">
          <ActionCard 
            title="Add New Reminder"
            description="Schedule a notification for later"
            onClick={onAddReminderClick}
          />
          <ActionCard 
            title="Manage ESP32 Devices"
            description="View and connect your IoT hardware"
            onClick={() => setCurrentPage(Page.Devices)}
          />
           <ActionCard 
            title="Create a Room"
            description="Start a new notification room for users"
            onClick={onAddRoomClick}
          />
        </div>
      </section>
    </>
  );

  const UserDashboard = () => {
    const userJoinedRooms = rooms.filter(room => joinedRooms.includes(room.code));

    return (
      <>
        <section className="mt-12">
            <h2 className="text-2xl font-semibold text-white">Upcoming Reminders</h2>
            {reminders.length > 0 ? (
                <div className="mt-4 space-y-3">
                    {reminders.map(reminder => (
                        <div key={reminder.id} className={`bg-surface p-4 rounded-lg shadow-md transition-opacity ${reminder.active ? 'opacity-100' : 'opacity-50'}`}>
                            <p className={`font-medium ${reminder.active ? 'text-white' : 'text-gray-500 line-through'}`}>{reminder.title}</p>
                            <p className={`text-sm ${reminder.active ? 'text-on-surface-secondary' : 'text-gray-600'}`}>{reminder.time}</p>
                        </div>
                    ))}
                </div>
            ) : (
                <p className="mt-4 text-on-surface-secondary">No reminders scheduled by the admin yet.</p>
            )}
        </section>

        <section className="mt-12">
          <h2 className="text-2xl font-semibold text-white">Joined Rooms</h2>
          {userJoinedRooms.length > 0 ? (
              <div className="mt-4 space-y-3">
                  {userJoinedRooms.map(room => (
                      <div key={room.id} className="bg-surface p-4 rounded-lg shadow-md flex items-center gap-4">
                          <UsersIcon className="w-8 h-8 text-primary flex-shrink-0" />
                          <div>
                              <p className="font-medium text-white">{room.name}</p>
                              <p className="text-sm text-on-surface-secondary font-mono tracking-widest">{room.code}</p>
                          </div>
                      </div>
                  ))}
              </div>
          ) : (
              <p className="mt-4 text-on-surface-secondary">You haven't joined any rooms yet.</p>
          )}
        </section>

        <section className="mt-12">
          <h2 className="text-2xl font-semibold text-white">Actions</h2>
          <div className="mt-4 flex flex-col gap-4">
            <ActionCard 
              title="Join Room"
              description="Enter a room code to get notifications"
              onClick={onJoinRoomClick}
            />
             <ActionCard 
              title="Admin Info"
              description="View information about your administrator"
              onClick={() => {}} // Placeholder
            />
             <ActionCard 
              title="View All Reminders"
              description="Check your upcoming scheduled reminders"
              onClick={() => setCurrentPage(Page.Reminders)}
            />
          </div>
        </section>
      </>
    );
  };

  return (
    <div className="py-8">
      <header>
        <h1 className="text-4xl font-bold text-white">InfoX</h1>
        <p className="text-lg text-on-surface-secondary mt-1">
            Welcome, {userRole === 'admin' ? 'Admin' : 'User'}
        </p>
      </header>

      {userRole === 'admin' ? <AdminDashboard /> : <UserDashboard />}
      
    </div>
  );
};

export default HomePage;
