import React from 'react';
import { Device } from '../../types';

const PlusIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
    </svg>
);

const ChipIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 7.5h-15a1.5 1.5 0 0 0-1.5 1.5v6a1.5 1.5 0 0 0 1.5 1.5h15a1.5 1.5 0 0 0 1.5-1.5v-6a1.5 1.5 0 0 0-1.5-1.5Z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 3v4.5M7.5 3v4.5M16.5 16.5V21M7.5 16.5V21M3 12h1.5M21 12h-1.5" />
    </svg>
);

interface DevicesPageProps {
    devices: Device[];
    onAddDeviceClick: () => void;
    onDisconnectDevice: (id: number) => void;
}

const DevicesPage: React.FC<DevicesPageProps> = ({ devices, onAddDeviceClick, onDisconnectDevice }) => {
    return (
        <div className="relative min-h-full py-8">
            <h1 className="text-4xl font-bold text-white mb-8">Connected Devices</h1>
            
            {devices.length === 0 ? (
                <div className="flex flex-col items-center justify-center text-center text-on-surface-secondary mt-24">
                    <ChipIcon className="w-24 h-24 mb-4" />
                    <h2 className="text-2xl font-semibold text-on-surface">No devices connected</h2>
                    <p className="mt-2">Tap + to connect your first ESP32</p>
                </div>
            ) : (
                <div className="space-y-4">
                    {devices.map(device => (
                        <div key={device.id} className="bg-surface p-4 rounded-lg flex items-center justify-between shadow-md">
                            <div className="flex items-center gap-4">
                               <ChipIcon className="w-8 h-8 text-primary" />
                                <div>
                                    <p className="text-lg font-medium text-white">{device.name}</p>
                                    <p className="text-sm text-green-400">Connected</p>
                                </div>
                            </div>
                           <button 
                                onClick={() => onDisconnectDevice(device.id)}
                                className="text-red-500 hover:text-red-400 text-sm font-semibold"
                           >
                                Disconnect
                           </button>
                        </div>
                    ))}
                </div>
            )}

            <button
                onClick={onAddDeviceClick}
                className="fixed bottom-28 right-6 bg-primary text-base w-16 h-16 rounded-full flex items-center justify-center shadow-lg hover:bg-opacity-80 transition-transform transform hover:scale-105"
                aria-label="Connect new device"
            >
                <PlusIcon className="w-8 h-8" />
            </button>
        </div>
    );
};

export default DevicesPage;