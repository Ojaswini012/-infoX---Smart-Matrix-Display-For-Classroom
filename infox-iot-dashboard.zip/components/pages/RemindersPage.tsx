
import React from 'react';
import { Reminder } from '../../types';

const ClockIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);

const PlusIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
    </svg>
);


interface RemindersPageProps {
    reminders: Reminder[];
    onAddReminderClick: () => void;
    toggleReminder: (id: number) => void;
}

const RemindersPage: React.FC<RemindersPageProps> = ({ reminders, onAddReminderClick, toggleReminder }) => {
    return (
        <div className="relative min-h-full py-8">
            <h1 className="text-4xl font-bold text-white mb-8">Reminders</h1>
            
            {reminders.length === 0 ? (
                <div className="flex flex-col items-center justify-center text-center text-on-surface-secondary mt-24">
                    <ClockIcon className="w-24 h-24 mb-4" />
                    <h2 className="text-2xl font-semibold text-on-surface">No reminders yet</h2>
                    <p className="mt-2">Tap + to create your first reminder</p>
                </div>
            ) : (
                <div className="space-y-4">
                    {reminders.map(reminder => (
                        <div key={reminder.id} className="bg-surface p-4 rounded-lg flex items-center justify-between shadow-md">
                            <div>
                                <p className={`text-lg font-medium ${reminder.active ? 'text-white' : 'text-gray-500 line-through'}`}>{reminder.title}</p>
                                <p className={`text-sm ${reminder.active ? 'text-on-surface-secondary' : 'text-gray-600 line-through'}`}>{reminder.time}</p>
                            </div>
                            <label className="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" checked={reminder.active} onChange={() => toggleReminder(reminder.id)} className="sr-only peer" />
                                <div className="w-11 h-6 bg-gray-600 rounded-full peer peer-focus:ring-2 peer-focus:ring-primary/50 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                            </label>
                        </div>
                    ))}
                </div>
            )}

            <button
                onClick={onAddReminderClick}
                className="fixed bottom-28 right-6 bg-primary text-base w-16 h-16 rounded-full flex items-center justify-center shadow-lg hover:bg-opacity-80 transition-transform transform hover:scale-105"
                aria-label="Add new reminder"
            >
                <PlusIcon className="w-8 h-8" />
            </button>
        </div>
    );
};

export default RemindersPage;
