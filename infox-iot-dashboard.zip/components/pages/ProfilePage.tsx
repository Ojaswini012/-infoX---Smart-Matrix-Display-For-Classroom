
import React from 'react';
import { UserIcon } from '../../constants';
import { UserRole } from '../../types';

interface ProfilePageProps {
    onLogout: () => void;
    userRole: UserRole | null;
    onSwitchRole: () => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ onLogout, userRole, onSwitchRole }) => {
    return (
        <div className="py-8">
            <h1 className="text-4xl font-bold text-white mb-8">Profile</h1>
            <div className="flex flex-col items-center justify-center text-center text-on-surface-secondary mt-12 sm:mt-24 bg-surface p-8 rounded-lg">
                <UserIcon className="w-24 h-24 mb-4 text-primary" />
                <h2 className="text-2xl font-semibold text-on-surface capitalize">{userRole}</h2>
                <p className="mt-2">{userRole}@infox.app</p>
                 <div className="flex gap-4 mt-8">
                    <button
                        onClick={onSwitchRole}
                        className="bg-primary text-base font-bold py-3 px-8 rounded-lg hover:bg-opacity-80 transition-colors">
                        Switch Role
                    </button>
                    <button 
                        onClick={onLogout}
                        className="bg-red-500 text-white font-bold py-3 px-8 rounded-lg hover:bg-red-600 transition-colors">
                        Log Out
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ProfilePage;
