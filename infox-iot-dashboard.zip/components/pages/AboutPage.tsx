
import React from 'react';

const BellAlertIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.857 17.082a23.848 23.848 0 0 0 5.454-1.31A8.967 8.967 0 0 1 18 9.75V9A6 6 0 0 0 6 9v.75a8.967 8.967 0 0 1-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 0 1-5.714 0m5.714 0a3 3 0 1 1-5.714 0M12 18.75a.75.75 0 0 0 .75-.75V13.5a.75.75 0 0 0-1.5 0v4.5a.75.75 0 0 0 .75.75Z" />
    </svg>
);

const UsersIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m-7.5-2.962a3.75 3.75 0 1 0-7.5 0 3.75 3.75 0 0 0 7.5 0ZM10.5 1.5a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);

const ChipIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 7.5h-15a1.5 1.5 0 0 0-1.5 1.5v6a1.5 1.5 0 0 0 1.5 1.5h15a1.5 1.5 0 0 0 1.5-1.5v-6a1.5 1.5 0 0 0-1.5-1.5Z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 3v4.5M7.5 3v4.5M16.5 16.5V21M7.5 16.5V21M3 12h1.5M21 12h-1.5" />
    </svg>
);

const AiIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456Z" />
    </svg>
);


const FeatureCard: React.FC<{icon: React.ReactNode, title: string, description: string}> = ({icon, title, description}) => (
    <div className="bg-surface p-6 rounded-lg flex items-start gap-4">
        <div className="text-primary flex-shrink-0">{icon}</div>
        <div>
            <h3 className="text-lg font-semibold text-white">{title}</h3>
            <p className="text-on-surface-secondary mt-1">{description}</p>
        </div>
    </div>
);

const AboutPage: React.FC = () => {
  return (
    <div className="py-8">
      <header className="text-center">
        <h1 className="text-5xl font-bold text-primary tracking-wider">InfoX</h1>
        <p className="text-lg text-on-surface-secondary mt-2">Version 1.0.0</p>
      </header>
      
      <section className="mt-8 max-w-2xl mx-auto text-center">
        <p>
          InfoX is a versatile IoT notification platform that bridges the gap between your hardware and your screen. Connect your ESP32 devices, create notification rooms, and receive instant alerts and reminders.
        </p>
      </section>

      <section className="mt-12">
        <h2 className="text-2xl font-semibold text-white mb-4">Key Features</h2>
        <div className="space-y-4">
          <FeatureCard 
            icon={<ChipIcon className="w-8 h-8"/>}
            title="ESP32 Integration"
            description="Easily connect and manage your ESP32 devices to send notifications to the app."
          />
          <FeatureCard 
            icon={<BellAlertIcon className="w-8 h-8"/>}
            title="Scheduled Reminders"
            description="Admins can schedule and broadcast time-based reminders to all users in a room."
          />
           <FeatureCard 
            icon={<UsersIcon className="w-8 h-8"/>}
            title="Notification Rooms"
            description="Create or join rooms using unique codes to receive targeted notifications."
          />
          <FeatureCard 
            icon={<AiIcon className="w-8 h-8"/>}
            title="AI-Powered Suggestions"
            description="Leverage the Gemini API to generate creative and context-aware reminder texts."
          />
        </div>
      </section>

      <footer className="mt-16 text-center text-on-surface-secondary">
        <p>Your hardware, your notifications.</p>
        <p>&copy; 2025 InfoX. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default AboutPage;
