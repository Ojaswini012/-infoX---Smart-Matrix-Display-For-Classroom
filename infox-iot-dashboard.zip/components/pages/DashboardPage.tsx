import React, { useMemo } from 'react';
import { Task, TaskStatus } from '../../types';
import TaskColumn from '../TaskColumn';

const PlusIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
    </svg>
);

interface DashboardPageProps {
  tasks: Task[];
  onAddTaskClick: () => void;
  onUpdateStatus: (id: string, status: TaskStatus) => void;
  onDeleteTask: (id: string) => void;
}

const DashboardPage: React.FC<DashboardPageProps> = ({ tasks, onAddTaskClick, onUpdateStatus, onDeleteTask }) => {
  
  const { todoTasks, inProgressTasks, doneTasks } = useMemo(() => {
    const todoTasks = tasks.filter(t => t.status === 'todo');
    const inProgressTasks = tasks.filter(t => t.status === 'inProgress');
    const doneTasks = tasks.filter(t => t.status === 'done');
    return { todoTasks, inProgressTasks, doneTasks };
  }, [tasks]);

  return (
    <div className="relative min-h-full py-8">
      <header className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold text-white">Task Manager</h1>
          <p className="text-lg text-on-surface-secondary mt-1">
              Stay organized, stay informed.
          </p>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <TaskColumn
          title="To Do"
          tasks={todoTasks}
          onUpdateStatus={onUpdateStatus}
          onDelete={onDeleteTask}
        />
        <TaskColumn
          title="In Progress"
          tasks={inProgressTasks}
          onUpdateStatus={onUpdateStatus}
          onDelete={onDeleteTask}
        />
        <TaskColumn
          title="Done"
          tasks={doneTasks}
          onUpdateStatus={onUpdateStatus}
          onDelete={onDeleteTask}
        />
      </div>

      <button
          onClick={onAddTaskClick}
          className="fixed bottom-28 right-6 bg-primary text-base w-16 h-16 rounded-full flex items-center justify-center shadow-lg hover:bg-opacity-80 transition-transform transform hover:scale-105 z-10"
          aria-label="Add new task"
      >
          <PlusIcon className="w-8 h-8" />
      </button>
    </div>
  );
};

export default DashboardPage;