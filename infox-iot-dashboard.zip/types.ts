
export enum Page {
  Dashboard = 'Dashboard',
  Devices = 'Devices',
  Reminders = 'Reminders',
  Contact = 'Contact',
  Profile = 'Profile',
  About = 'About',
}

export type UserRole = 'user' | 'admin';

export interface User {
    isAuthenticated: boolean;
    role: UserRole | null;
}

export interface Reminder {
  id: number;
  title: string;
  time: string;
  active: boolean;
}

export interface Device {
  id: number;
  name: string;
}

export interface Room {
  id: number;
  name: string;
  code: string;
}

// Fix: Added missing Task and TaskStatus types to resolve import errors.
export type TaskStatus = 'todo' | 'inProgress' | 'done';

export interface Task {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  status: TaskStatus;
}
